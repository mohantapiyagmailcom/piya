package com.pdroid.welcometomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private EditText editTextEmail;
    private EditText editTextPassword;
    private CheckBox checkBoxShowPassword;
    private Button buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextEmail = findViewById(R.id.Email);
        editTextPassword = findViewById(R.id.Password);
        checkBoxShowPassword = findViewById(R.id.ShowPassword);
        buttonLogin = findViewById(R.id.Loginbutton);


        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextEmail.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                if (TextUtils.isEmpty(email) || !isValidEmail(email)) {
                    editTextEmail.setError("Invalid email");
                    return;
                }

                if (TextUtils.isEmpty(password) || password.length() < 6 || password.contains(" ")) {
                    editTextPassword.setError("Invalid password");
                    return;
                }

                Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,  RegistrationActivity.class);
                startActivity(intent);
                finish();
            }
        });

        checkBoxShowPassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    editTextPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                } else {
                    editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
            }
        });

        Intent intent = new Intent(MainActivity.this,  RegistrationActivity.class);
        startActivity(intent);
        finish();
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        return !TextUtils.isEmpty(email) && Pattern.matches(emailRegex, email);
    }


}