package com.pdroid.welcometomyapp;

public class Registrationprovider {
    private static Registrationprovider instance;

    private String name;
    private String email;
    private String password;
    private String dob;

//    private Registrationprovider(String name, String email, String password, String dob) {
//        this.name = name;
//        this.email = email;
//        this.password = password;
//        this.dob = dob;
//    }

    public static Registrationprovider getInstance() {
        if (instance == null) {
            instance = new Registrationprovider();
        }
        return instance;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setDOB(String dob) {
        this.dob = dob;
    }

    public String getDOB() {
        return dob;
    }
}
