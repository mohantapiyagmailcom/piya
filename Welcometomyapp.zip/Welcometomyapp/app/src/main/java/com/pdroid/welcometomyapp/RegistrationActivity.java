package com.pdroid.welcometomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import java.util.Calendar;

public class RegistrationActivity extends AppCompatActivity {
    private EditText editTextName, editTextEmail, editTextPassword, editTextDOB;
    private CheckBox checkBoxShowPassword;
    private Button buttonRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        editTextName = findViewById(R.id.TextName);
        editTextEmail = findViewById(R.id.TextEmail);
        editTextPassword = findViewById(R.id.TextPassword);
        editTextDOB = findViewById(R.id.TextDOB);
        checkBoxShowPassword = findViewById(R.id.ShowPassword);
        buttonRegister = findViewById(R.id.Registerbutton);

        checkBoxShowPassword.setOnCheckedChangeListener((compoundButton, isChecked) -> {
            if (isChecked) {
                editTextPassword.setTransformationMethod(null);
            } else {
                editTextPassword.setTransformationMethod(new PasswordTransformationMethod());
            }
        });

        editTextDOB.setOnClickListener(view -> {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(RegistrationActivity.this,
                    (datePicker, yearSelected, monthSelected, daySelected) -> {
                        String dob = (monthSelected + 1) + "/" + daySelected + "/" + yearSelected;
                        editTextDOB.setText(dob);
                    }, year, month, day);
            datePickerDialog.show();
        });

        buttonRegister.setOnClickListener(view -> {

            String name = editTextName.getText().toString().trim();
            String email = editTextEmail.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();
            String dob = editTextDOB.getText().toString().trim();
            validateFields(name,email,password);

            if (validateFields(name, email, password)) {
                Registrationprovider registrationProvider = Registrationprovider.getInstance();
                registrationProvider.setName(name);
                registrationProvider.setEmail(email);
                registrationProvider.setPassword(password);
                registrationProvider.setDOB(dob);

            }
        });

    }

    private boolean validateFields(String name, String email, String password) {

        if (name.isEmpty()) {
            editTextName.setError("Name is required");
            return false;
        }

        if (email.isEmpty()) {
            editTextEmail.setError("Email is required");
            return false;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Password is required");
            return false;
        }

        if (password.length() < 6) {
            editTextPassword.setError("Password must be at least 6 characters long");
            return false;
        }

        return true;

    }
}